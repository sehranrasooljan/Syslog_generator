A simple shell script to generate syslog messages with netcat.  It sends a X random syslog messages every Y seconds to a device of your designation.

Change the variables to match your environment and run!
